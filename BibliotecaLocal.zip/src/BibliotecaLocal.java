public class BibliotecaLocal {
    public static void main(String[] args) {
        Autor autor1 = new Autor("Machado de Assis");
        Editora editora1 = new Editora("Editora Brasileira");

        Livro livro1 = new LivroNacional("Dom Casmurro", autor1, editora1, 29.90);

        Cliente cliente1 = new Cliente("João Silva", "Rua A, 123");

        Pedido pedido1 = new Pedido(cliente1);
        pedido1.adicionarItem(new ItemPedido(livro1, 2));

        Pagamento pagamento1 = new PagamentoCartao(pedido1.calcularTotal(), "1234-5678-9012-3456");
        pedido1.setPagamento(pagamento1);

        System.out.println("Detalhes do Pedido:");
        for (ItemPedido item : pedido1.getItens()) {
            item.getLivro().mostrarDetalhes();
            System.out.println("Quantidade: " + item.getQuantidade());
            System.out.println("Subtotal: R$" + item.getSubtotal());
        }
        System.out.println("Total do Pedido: R$" + pedido1.calcularTotal());

        pedido1.getPagamento().realizarPagamento();
    }
}