public class ItemPedido {
    private Livro livro;
    private int quantidade;

    public ItemPedido(Livro livro, int quantidade) {
        this.livro = livro;
        this.quantidade = quantidade;
    }

    public double getSubtotal() {
        return livro.getPreco() * quantidade;
    }

    public Livro getLivro() {
        return livro;
    }

    public int getQuantidade() {
        return quantidade;
    }
}