public class LivroNacional extends Livro {
    public LivroNacional(String titulo, Autor autor, Editora editora, double preco) {
        super(titulo, autor, editora, preco);
    }

    @Override
    public void mostrarDetalhes() {
        System.out.println("Título: " + getTitulo());
        System.out.println("Autor: " + getAutor().getNome());
        System.out.println("Editora: " + getEditora().getNome());
        System.out.println("Preço: " + getPreco());
    }
}